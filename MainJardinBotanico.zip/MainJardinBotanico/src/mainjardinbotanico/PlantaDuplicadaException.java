package mainjardinbotanico;

public class PlantaDuplicadaException extends Exception {
    public PlantaDuplicadaException(String mensaje) {
        super(mensaje);
    }
}
