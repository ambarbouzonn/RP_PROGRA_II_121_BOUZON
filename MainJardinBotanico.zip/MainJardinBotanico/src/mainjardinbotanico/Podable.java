package mainjardinbotanico;

interface Podable {
    void podar();
}
