package mainjardinbotanico;

public enum TEMPORADA {
    PRIMAVERA, VERANO, OTOÑO, INVIERNO
}